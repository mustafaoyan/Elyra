# Siper Debian Direct Installation

Package: `siper-pardus_1.0.1-2_amd64.deb`

Install on Pardus 25.1 with an active internet connection:

```bash
sudo apt install ./siper-pardus_1.0.1-2_amd64.deb
```

The package installs Pardus dependencies, creates the isolated Siper virtual
environment, installs CustomTkinter from PyPI, enables the daemon, and adds the
normal local desktop account(s) to the read/scan IPC group. It never assigns the
sensitive `elliot-admin` group automatically.

After installation, log out and back in once, then open **Siper** from the Pardus
application menu. The desktop launcher uses `Terminal=false`.

Safe defaults remain `MONITOR_ONLY` with automatic runtime responses disabled.
