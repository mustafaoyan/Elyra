# Siper Standalone Desktop Application

This release is designed so the privileged Siper daemon runs silently as a
`systemd` service and the unprivileged graphical interface opens like a normal
Pardus application.

## Normal user flow

1. Install Siper once with the installer or Debian package.
2. Log out and log in once if the installer added the user to the `elliot` IPC group.
3. Open the Pardus application menu.
4. Search for **Siper** and click it.

No terminal is required for normal use. The desktop entry has `Terminal=false`
and starts `/usr/local/bin/siper-app`. The launcher redirects technical GUI
messages to:

```text
~/.local/state/siper/gui.log
```

The daemon is started automatically at boot by `elliot.service`; `siper.service`
is its public alias. The GUI remains unprivileged and communicates with the
daemon through the protected Unix-domain socket.

## Desktop shortcut

When `scripts/install.sh` is used with `--user USER`, the installer attempts to
place `Siper.desktop` in that user's configured desktop folder. The shortcut can
be disabled with:

```bash
sudo ./scripts/install.sh --user "$USER" --no-desktop-shortcut
```

The application-menu entry is installed regardless of this option.

## Troubleshooting

Check the GUI diagnostic log without keeping a terminal open during normal use:

```bash
cat ~/.local/state/siper/gui.log
```

Check the background daemon separately:

```bash
sudo systemctl status siper.service --no-pager
```

The application continues to start in `MONITOR_ONLY` mode. Creating a desktop
launcher does not enable blocking, termination, or quarantine.
