# Siper 1.0.1 Release Notes — Standalone Desktop Fallback

This release is derived from the verified Stage 15.3 source and focuses only on
professional desktop startup and packaging. It does not enable enforcement or
automatic destructive responses.

## Standalone desktop changes

- Added `/usr/local/bin/siper-app`, a dedicated graphical launcher.
- The Pardus application-menu entry is now named **Siper**.
- The desktop entry uses `Terminal=false` and launches `siper-app`.
- GUI console output is redirected to the private user log
  `~/.local/state/siper/gui.log` instead of flowing in a visible terminal.
- The source installer attempts to create a clickable `Siper.desktop` shortcut
  for the selected user.
- The background daemon remains managed silently by `systemd`.
- The Debian package includes the standalone launcher and refreshes the desktop
  application database when available.
- The existing `siper-gui` and `elliot-gui` technical commands remain for
  compatibility and troubleshooting.

## Safety posture

The installed service still starts in `MONITOR_ONLY` mode. Automatic denial,
termination and quarantine remain disabled by default. This release changes
only the startup experience and does not claim general malware-detection
validation.
